<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<?php include("/home/forge/".$domain."/lpsource/header.php"); ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
<link rel="stylesheet" href="inc/ddexitpop.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js" crossorigin="anonymous"></script> 

<script src="inc/ddexitpop.js"></script>

<script>

//*** Initialize DD Exit Pop Up Script:

jQuery(function(){
  ddexitpop.init({
    contentsource: ['id', 'ddexitpop1'],
    mobileshowafter: 15000,
    fxclass: 'random',
    displayfreq: 'always',
    onddexitpop: function($popup){
      console.log('Exit Pop Animation Class Name: ' + ddexitpop.settings.fxclass)
    }

  })
})

</script>



<!--meta http-equiv="Content-Type" content="text/html; charset=UTF-8"-->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

<meta name="HandheldFriendly" content="True">
<meta name="MobileOptimized" content="320">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
<meta name="CLNVevoHelper:beacon" content="">
<meta name="CLn_ct" content="blog">
<meta name="CLn_title" content="">
<meta name="CLn_desc" content="">
<meta name="CLn_date" content="2014-05-21:16-58">
<title>NSW Mum Discovers 62 Year-Old Model's $4 Advice To a Wrinkle-Free Face!</title>
<link rel="stylesheet" id="news-stylesheet-css" href="inc/main.css" type="text/css" media="all">
<link rel="stylesheet" id="news-stylesheet-css" href="inc/style.css" type="text/css" media="all">

</head>
<body class="single single-post postid-1829462 single-format-standard" data-twttr-rendered="true">

<div class="mboxDefault" id="globalMbox" style="visibility: visible; display: block;"></div>
<div class="mboxDefault" id="globalMbox" style="visibility: visible; display: block;"></div>
<div id="page_root">
  <div class="navbar navbar-fixed-top-not">
    <div id="navbar-inner">
      <div class="container">
        <div class="brand pull-left"> <a class="icon-actions-close" id="nav-close"> <span class="icon-datas-list"> </span> </a> </div>
           <div class="title"><span class="sitename"></span> </div>
      </div>
    </div>
    <div id="nav-dim"></div>
  </div>
  <div class="item promo-block lead-image">
    <div class="media">
      <div class="container-lead-image">
        <div class="content">
          <div class="photo"> <a href="#" target="_blank"><img src="inc/top6.png" title="" class="js-srcset-img shortcode-image" alt="" width="100%"></a> <span class="photocredit"></span> </div>
          <!--<img src=""/>-->
        </div>
      </div>
    </div>
    <div class="photocredit"></div>
  </div>
  <div class="container">
    <div id="content" class="clearfix">
      <div class="row">
        <!--div id="main" class=" col-sm-8 clearfix" role="main"-->
        <div id="main" class="col-xs-12 col-sm-12 col-md-8 clearfix" role="main">
          <div class="row">
            <article id="post-1829462" class="post-1829462 post type-post status-publish format-standard has-post-thumbnail hentry category-celebrity clearfix" role="article">
              <div class="col-md-12 story">
                <div class="header"> <span class="headline">
                  <h1 class="h1" style="margin-top:10px;"><a href="#" target="_blank">
                  <font color="red">Would You Spend $4 To Look 15 Years Younger?</font>
                  NSW Mum Discovers 62 Year-Old Model's Advice To a Wrinkle-Free Face!</a></h1>
                  </span>
                  <div class="subhead"><font color="red">Doctors Shocked Over New Wrinkle Killer</font> </div>
                </div>
                <section class="entry-content clearfix">
                  <div class="hr"></div>
                  <span class="byline">  <span class="author"></span> <span class="date">
                  <script> 
                var mydate=new Date() 
                var year=mydate.getYear() 
                if (year < 1000) 
                year+=1900 
                var day=mydate.getDay() 
                var month=mydate.getMonth() 
                var daym=mydate.getDate() 
                if (daym<10) 
                daym="0"+daym 
                var dayarray=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday") 
                var montharray=new 
                Array("January","February","March","April","May","June","July","August","September","October","November","December") 
                document.write(""+dayarray[day]+", "+montharray[month]+" "+daym+", "+year+"") 
                  
              </script>
                  </span> </span>
                  <center>
                   <a href="#" target="_blank"> <img src="inc/top1.jpg" width="600"></a>
                  </center>
                  <br>
                  <p> <b>(CL)</b> - Melanie Rose, a 53 year old part-time Receptionist in Sydney, was able to
                  rewind <a href="#" target="_blank"><b>10-15 years off her face</b></a>, leaving
                  her friends and family 'absolutely shocked' at her glowing &amp; youthful
                  appearance. Melanie, a mother of 3, didn't have the extra cash to try out every celebrity
                  endorsed anti-aging "miracle cream" out there, let alone splurge on
                  ridiculously expensive things like plastic surgery or botox.

</p><p>Before trying this simple trick, she admits to falling for several skin care
gimmicks that gave her zero results. After wasting hours of her time,
she was left with nothing to show for it. </p>
                  <p><i>"The last 15 years I've struggled with wrinkles, I was always looking
                  old and tired. I tried things like Botox and considered expensive surgery but I'm a single
                  Mum with 3 kids at home and I am also working part-time and I can't afford
                  those other
                  risky solutions which just don't work as good as they promise."</i></p>
                  
                  
                  <p><i>"Since then, I haven't looked back...<a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a>
                  has been amazing, I literally look 10-15 years younger than I did before. The best part of it all, I can
                  tell that my kids are proud
                  of me." - Melanie  Rose</i></p>
                  
                  
                  <p>We sat down with Melanie  to ask her more about 
                  about 
                  <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong>
                  </a> and whether or not that is all that she used to lose her eye-bags and wrinkles so quickly.</p>
                  <p><strong>CL:</strong> Tell us, how did you know where to start?</p>
                  <p><i><strong>Melanie :</strong> To be honest, I really didn't. After a year of researching and speaking to other friends about
                  their own skincare habits, I was about to give up and accept that nothing could be done
                  about my appearance. But then one morning I saw <a href="#" target="_blank"><strong>Christie Brinkley</strong></a> interviewed on Sunrise, I was blown away!
                  She's 62 years old after all! 10 years older than me, but <a href="#" target="_blank"><strong>looks about
                  20 years younger!</strong></a> She's not the first celebrity to have a skincare product, but she can definitely back it up with her
                  appearance! And that's when I decided to at least give it a try."</i></p>
                  
                  <p><strong>CL:</strong> So, why did you decide to try out <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a>?</p>
                  <p><i><strong>Melanie :</strong> It's sort of funny. I am a big fan of Christie Brinkley,
                  and while I was looking into wrinkle solution stories of others I decided to see if
                  I could find out more about how Brinkley is able to look so incredible at her age...she really is 62!!!
                  Surprisingly, even though I had heard of  <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a>,
 I had never bothered to
                  give it a try. that was until I saw her appearance on 
Channel 7, where she credited her entire youthful appearance to
                  <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a></i>. It was so good that she bought the company!</p>
                  <div class="results" style="background: #EEE; border: 1px solid #ddd; text-align: center;">
                    <a href="#" target="_blank"><img src="inc/cb1.jpg" height="342" width="608"></a>
                  <b><em>Christie Brinkley at 62 years of age is living proof that <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a>
                  is the only skincare that can eliminate wrinkles and leave you looking years younger
                  </em></b>
                  </div>
                  <p><strong>CL:</strong> Was it expensive to get <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a>?</p>
                  <p><i><strong>Melanie :</strong> It actually was not very expensive at all,
                  and thankfully so. By the time I had found out about
                  <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a>
                  , I had about $13 left in my weekly budget.
                  Since <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a> is a completely natural formula, Brinkley
                  doesn't spend a lot to manufacture it. Additionally, they actually provided me with a
                  <a href="#" target="_blank"><b>free 1 month sample</b></a> and I just paid for shipping! So I got
                  <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a> for 4.95, and I still had $8 left in my budget!</i></p>
                  <p><strong>CL:</strong> That's impressive! Could you explain how it works?</p>
                  <p><i><strong>Melanie :</strong> There isn't much to it, and that is the appeal of it all.
                  Every morning and every evening you can apply the cream...simple. After using it, <a href="#" target="_blank"><strong>your face feels warm and tingly!</strong></a>
 Other than that, I didn't do a single thing with my face. 30 days 
later, and my eye-bags and wrinkles have diminished remarkably.
                  I look 10 to 15 years younger!</i></p>
                  
                  
                  <p>Since the interview, Melanie has shared
                  the <a href="#" target="_blank">
                  </a><a href="#" target="_blank"><strong><?php echo $offerName; ?></strong>
                  </a> with her friend, Lauren, who had also
                  been struggling with wrinkles and eye-bags. Lauren's results are even more impressive
                  than Melanie 's.</p>
                  <div class="results" style="background: #EEE; border: 1px solid #ddd; text-align: center;"><a href="#" target="_blank">
                  <img src="inc/5C.jpg" height="342" width="608"></a>
                    <p style="text-align: center;padding:6px;"> <em> <strong>Lauren was able to remove over 20+
                    years of aging from her face with this advice!</strong></em> </p>
                  </div>
                  
                  
                  <p><strong>Why is <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a> so
                  effective?</strong></p>
                  <p><a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a> contains the
                  The Collagen Formula which is the key to maintaining healthy, youthful skin. It’s a powerful Botox-replacement
                  formula rich in antioxidants like <a href="#" target="_blank">Argireline</a>
 and natural fruit extracts. It slows the rate of
                  free-radical damage and reverses any existing damage. 
Those evil free-radicals are what cause your skin dryness, fine lines, 
and wrinkles. It helps combat and even reverse time’s
                  effect on your skin, because it forces your skin to 
produce collagen – a protein which tightens the
                  skin from the inside out.</p>
                  
                  
                  <div style="clear: both;"></div>
                  <div class="results" style="text-align: center;">
                    <a href="#" target="_blank"> <img src="inc/results.png" height="342" width="608"></a>
                         <p style="text-align: center;padding:6px; background: #EEE; border: 1px solid #ddd;"> <em> Since helping her
                    friend Lauren, Melanie  has gone on to share
                    the <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a> with many others!</em> </p>
                  </div>
                  <br>
                  
                  
                   <div class="results" style="text-align: center;">
                    <a href="#" target="_blank"> <img src="inc/ba12.jpg" height="342" width="608">
                    </a><a href="#" target="_blank"> <img src="inc/ba23.jpg" height="342" width="608"></a>
                         <p style="text-align: center;padding:6px; background: #EEE; border: 1px solid #ddd;"> <em> Mum's and Grandma's all over are
                         flocking to 
                    the <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a> to eliminate wrinkles and look years younger overnight!</em> </p>
                  </div>
                  
                  
                  
                  <div class="offer-list">
                    <h2><strong><a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a> </strong> has been clinically proven to:</h2>
                    <ol class="rectangle-list">
                      <li>Reduce Age Spots By More Than 130%</li>
                      <li>Flush Out Harmful Toxins From Your Face</li>
                      <li>Repair and Regenerate Skin After Suffering From Age, Dryness,
                      Environmental Stresses, or Irritation</li>
                      <li>Reduce and Tighten Wrinkles Overnight</li>
                    </ol>
                  </div>
                  <br>
                  <p>For our readers, Melanie Rose has provided the week by
                  week breakdown of her anti-aging process, the apple cider
                  vinegar recipe she used, and the link to get a free 1 month
                  sample of <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a> </p>
                  <p style="text-align:center; padding:6px; background-color:#FFC"> <span style="text-align:left;"> <strong>Results</strong> -
                  "The trick is <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a>
 contains
                  high concentrations of stem cells and peptides in
                  just the right concentrations. 
                  I saw results
                  almost overnight, but after 14 days, the results were 
literally shocking. I looked how I used to look 10 years ago!" - Melanie
 </span> </p>
                  <p>
                    </p><div class="results" style="background: #EEE; border: 1px solid #ddd; text-align: center;">
           
                     <a href="#" target="_blank"> <img class="contentImage" style="text-align: center;width:100%;" alt="4-weeks-1" src="inc/cb9.jpg" height="350" width="250"></a> <p></p>
               Christie with her daughter, they look like sisters! <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a> is in extremely high demand, please don't miss
               out on this offer
               
               
                    </div>
                  <p></p><center>
                  <p>1.  <b>In the morning, apply <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a>
                  </b><br>
                  </p><p>2. <b>In the evening, apply <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a>
                  before bed.</b></p></center><br>
                  <p></p>
                  <h2>We Decided To Put <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a> To The Test!</h2>
                  <div class="results" style="clear:both;">
                    <p class="bold">Day One:</p>
                    <img src="inc/eyes1.jpg" align="left" width="120">
                    <p> After the first day of using the <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a>,
                    I was surprised at how wonderful it made my skin 
feel. It felt like every last pore on my face was being tightened and 
pulled by a gigantic vacuum cleaner.

                    </p><p> I don't know how else to describe it! I 
could feel a warm tingling sensation on my cheeks, around my eyes, and 
on my forehead. I looked in the mirror and saw that my face looked a bit
 rosy - the result of revitalizing blood rushing to the surface of my 
skin to renew my face.
 </p>
                  <p>After both products were absorbed into my skin, my face looked firmer and had a beautiful glow to it.</p>
   <p></p>
                    <p class="bold">Day Five:</p>
                    <img src="inc/eyes2.jpg" align="left" width="120">
                    <p> After five days of using the <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a>  I was shocked at the drastic results.

</p><p>The lines, dark spots, and wrinkles - without question - were visibly reduced in size right before my eyes!

</p><p>I was astonished by the results, and literally felt 15 years younger again. It was like watching all my wrinkles
and fine lines vanish right off! Not only did my skin look younger, it also felt younger.

</p><p>Not only were the results amazing, they were incredibly easy to achieve, taking less than 15 minutes out of my day to
apply <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a>. </p>
                    
                    
                    
                    
                    <p class="bold">Day Fourteen:</p>
                    <img src="inc/eyes3.jpg" align="left" width="120">
                    <p> After 14 days, not only had all my doubts and scepticism
                    absolutely vanished - SO DID MY WRINKLES!

</p><p>The lines on my forehead, the loose, sagging skin on my neck, my crows’ feet – even
the age spots on my face had COMPLETELY disappeared. I've never felt or seen anything
tighten my skin with this kind of force before, no matter how expensive the product!

</p><p>After the 2 weeks, my skin not only stayed that way, it actually improved every day
until it became as beautiful and radiant as it was 20 years ago. By this point, all
my friends and family were
shocked. They couldn't believe the difference, and were convinced I was lying
about not getting botox! </p>
                    
                    
                    
                    
                    <p style="text-align:left;"><a href="#" target="_blank"> <img class="contentImage" style="text-align: center;width:100%;" alt="4-weeks-1" src="inc/5B.jpg" height="350" width="250"> </a></p>
                  </div>
                  <!-- /results -->
                  <div style="border-width: 3px; width: 100%; padding:20px" class="block-item">
                    <p> <span> <strong><span style="color: black;">*NOTE:</span></strong> Melanie  Rose has worked with
                    the official suppliers of <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a> to
                    temporarily provide free 1 month samples for our readers!</span></p>
                    <p></p>
                    <div class="notice"> **Update: <strong><span>LIMITED SAMPLES AVAILABLE</span></strong> - As of
                      <script> 
                var mydate=new Date() 
                var year=mydate.getYear() 
                if (year < 1000) 
                year+=1900 
                var day=mydate.getDay() 
                var month=mydate.getMonth() 
                var daym=mydate.getDate() 
                if (daym<10) 
                daym="0"+daym 
                var dayarray=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday") 
                var montharray=new 
                Array("January","February","March","April","May","June","July","August","September","October","November","December") 
                document.write(""+dayarray[day]+", "+montharray[month]+" "+daym+", "+year+"") 
                  
              </script>
                      , There ARE Still Samples Available! </div>
                    <br>
                    <strong class="yellow"><div id="spaces" style="font-size:20px;"><span style="color:orange;">(123)</span> viewing offer</div></strong><br>

                    
                    <div class="product-item">
                      <div class="picture"> <a href="#" target="_blank"> <img src="<?php echo $offerImg; ?>" height="300"></a> </div>
                      <div class="text"> <span>Step 1</span> <span class="big">RISK FREE 30 DAY SUPPLY OF
                      <a href="#" target="_blank">
                        </a><a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a>
                      </span> <a href="#" target="_blank" class="buy">GET A RISK FREE
                      SAMPLE</a><br>
                      <a href="#" target="_blank"><font size="1">(pay $4.95 s&amp;h -
                      see here for details)</font></a>
                      
                      <span class="small">
                      Sample Promotion Available On<br>
                        <b>
                        <script> 
                var mydate=new Date() 
                var year=mydate.getYear() 
                if (year < 1000) 
                year+=1900 
                var day=mydate.getDay() 
                var month=mydate.getMonth() 
                var daym=mydate.getDate() 
                if (daym<10) 
                daym="0"+daym 
                var dayarray=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday") 
                var montharray=new 
                Array("January","February","March","April","May","June","July","August","September","October","November","December") 
                document.write(""+dayarray[day]+", "+montharray[month]+" "+daym+", "+year+"") 
                  
              </script>
                        hurry! </b></span> </div>
                    </div>
                  </div>
                  <br>
                  <h3>Special: for a limited time you may be eligible for the full-range of <?php echo $offerName; ?> products,
                  including both day and night creams. Click the image below no later than <script> 
                var mydate=new Date() 
                var year=mydate.getYear() 
                if (year < 1000) 
                year+=1900 
                var day=mydate.getDay() 
                var month=mydate.getMonth() 
                var daym=mydate.getDate() 
                if (daym<10) 
                daym="0"+daym 
                var dayarray=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday") 
                var montharray=new 
                Array("January","February","March","April","May","June","July","August","September","October","November","December") 
                document.write(""+dayarray[day]+", "+montharray[month]+" "+daym+", "+year+"") 
                  
              </script> to find out!</h3>
                   <div class="picture"> <a href="#" target="_blank"> <img src="inc/cb6.jpg" height="300"></a> </div>
               
                </section>
              </div>
            </article>
            <b></b> </div>
          <b></b> </div>
        <b></b> </div>
      <b>
      <!-- end article section -->
      <div id="commentsContainer" class="sm4CommentsWidget sm4Widget flux4Widget flux4" data-widget="mobileComments" data-contenturi="id::mgid:wordpress:post:articles.CL.com:1829462::og::http://www.CL.com/news/1829462/rick-ross-rossfit-weight-loss/">
        <div class="comments">
          <div class="withThumbnails thumbnailsMedium withQuickView">
            <div class="mainHeader floatsWrapper">
              <div class="moduleContent">
                <div class="actionsPanel">
                  <section class="add-comment"> <br>
                    <h2 class="secondaryHeadline">Add A Comment</h2>
                    <span class="recent-comments">Recent Facebook Comments</span>
                    <div class="comment-system">
                      <div class="comment-left"> <img src="inc/cmnt-img1.jpg" alt="comment-image" height="50" width="50"> </div>
                      <div class="comment-right"> <span class="profile-name">Megan Lewis</span>
                        <div class="profile-content">
                          <div class="post-text">My friends and I have all been waiting for the <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a>
                          to hit the news. At least 5 of us have all used <a href="#" target="_blank"><strong><?php echo $offerName; ?></strong></a> and we all use it daily.
                          This 
                          changed all of our lives. Good luck to everyone  who
                          takes advantage of this wonderful opportunity. </div>
                          <div> <a class="post-reply">Reply</a> <span class="dotpos">.</span> <span class="post-number">13</span> <a class="post-like">Like</a> <span class="dotpos">.</span> <abbr class="post-time" title="Wednesday, May 30, 2012 at 8:06pm">12 minutes ago</abbr> </div>
                        </div>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                    <div class="comment-system">
                      <div class="comment-left"> <img src="inc/cmnt-img2.jpg" alt="comment-image" height="50" width="50"> </div>
                      <div class="comment-right"> <span class="profile-name"> Tanya Porquezr</span>
                        <div class="profile-content">
                          <div class="post-text">I saw Melanie 's combo going viral on FB last week and
                          all I have to say is WOW. I'm going to order <?php echo $offerName; ?> right now!</div>
                          <div> <a class="post-reply">Reply</a> <span class="dotpos">.</span> <span class="post-number">6</span> <a class="post-like">Like</a> <span class="dotpos">.</span> <abbr class="post-time" title="Wednesday, May 30, 2012 at 8:06pm">13 minutes ago</abbr> </div>
                        </div>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                    <div class="comment-system">
                      <div class="comment-left"> <img src="inc/cmnt-img3.jpg" alt="comment-image" height="50" width="50"> </div>
                      <div class="comment-right"> <span class="profile-name">Jennifer Jackson Mercer</span>
                        <div class="profile-content">
                          <div class="post-text">A friend of mine used and recommended it to me 3 weeks ago. 
                            I ordered the product and received them within 3 days (although I didn't get 
                            the discounted prices). The results have been incredible and I can't
                            wait to see what weeks 3 and 4 bring.</div>
                          <div> <a class="post-reply">Reply</a> <span class="dotpos">.</span> <span class="post-number">19</span> <a class="post-like">Like</a> <span class="dotpos">.</span> <abbr class="post-time" title="Wednesday, May 30, 2012 at 8:06pm">25 minutes ago</abbr> </div>
                        </div>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                    <div class="comment-system">
                      <div class="comment-left"> <img src="inc/cmnt-img4.jpg" alt="comment-image" height="50" width="50"> </div>
                      <div class="comment-right"> <span class="profile-name">Katy Barrott</span>
                        <div class="profile-content">
                          <div class="post-text">Never even thought about using this. I am very much
                          pleased after using this product.</div>
                          <div> <a class="post-reply">Reply</a> <span class="dotpos">.</span> <span class="post-number">53</span> <a class="post-like">Like</a> <span class="dotpos">.</span> <abbr class="post-time" title="Wednesday, May 30, 2012 at 8:06pm">about an hour ago</abbr> </div>
                        </div>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                    <div class="comment-system">
                      <div class="comment-left"> <img src="inc/cmnt-img5.jpg" alt="comment-image" height="50" width="50"> </div>
                      <div class="comment-right"> <span class="profile-name">Melanie  Gibson</span>
                        <div class="profile-content">
                          <div class="post-text">I saw this on the news. How lucky is this mom to
                          have found this opportunity!?!?! 
                            Thank you for sharing this tip! I just ordered both products.</div>
                          <div> <a class="post-reply">Reply</a> <span class="dotpos">.</span> <span class="post-number">3</span> <a class="post-like">Like</a> <span class="dotpos">.</span> <abbr class="post-time" title="Wednesday, May 30, 2012 at 8:06pm"> 1 hour ago</abbr> </div>
                        </div>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                    <div class="comment-system">
                      <div class="comment-left"> <img src="inc/cmnt-img6.jpg" alt="comment-image" height="50" width="50"> </div>
                      <div class="comment-right"> <span class="profile-name">Julie Keyse</span>
                        <div class="profile-content">
                          <div class="post-text">probably I'm a bit older than 
                            most of you folks. but this worked for me too! LOL! 
                            I can't say anything more exciting.Thanks for your inspirations!</div>
                          <div> <a class="post-reply">Reply</a> <span class="dotpos">.</span> <span class="post-number"></span> <a class="post-like">Like</a> <span class="dotpos">.</span> <abbr class="post-time" title="Wednesday, May 30, 2012 at 8:06pm">2 hours ago</abbr> </div>
                        </div>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                    <div class="comment-system">
                      <div class="comment-left"> <img src="inc/cmnt-img7.jpg" alt="comment-image" height="50" width="50"> </div>
                      <div class="comment-right"> <span class="profile-name">Sarah Williams</span>
                        <div class="profile-content">
                          <div class="post-text">My sister did this a few months ago, I waited to 
                            order my trials to see if it really worked and then they stopped giving 
                            out the trials! what a dumb move that turned out to be. glad to see 
                            the trials are back again, I wont make the same mistake.</div>
                          <div> <a class="post-reply">Reply</a> <span class="dotpos">.</span> <span class="post-number">12</span> <a class="post-like">Like</a> <span class="dotpos">.</span> <abbr class="post-time" title="Wednesday, May 30, 2012 at 8:06pm"> 2 hours ago</abbr> </div>
                        </div>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                    <div class="comment-system">
                      <div class="comment-left"> <img src="inc/cmnt-img8.jpg" alt="comment-image" height="50" width="50"> </div>
                      <div class="comment-right"> <span class="profile-name">Kirsten Bauman Riley</span>
                        <div class="profile-content">
                          <div class="post-text">I love the I'm going 
                            to give these products a chance to work their magic on me. I've tried 
                            everything out there and so far nothing has been good enough to help me.</div>
                          <div> <a class="post-reply">Reply</a> <span class="dotpos">.</span> <span class="post-number">30</span> <a class="post-like">Like</a> <span class="dotpos">.</span> <abbr class="post-time" title="Wednesday, May 30, 2012 at 8:06pm"> 2 hours ago</abbr> </div>
                        </div>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                    <div class="comment-system">
                      <div class="comment-left"> <img src="inc/cmnt-img9.jpg" alt="comment-image" height="50" width="50"> </div>
                      <div class="comment-right"> <span class="profile-name">Celia Kilgard</span>
                        <div class="profile-content">
                          <div class="post-text">worked for me! I worked just like I thought it would.
                            It was easy enough and I just want others to know when something works. I Look 15 years younger</div>
                          <div> <a class="post-reply">Reply</a> <span class="dotpos">.</span> <span class="post-number">53</span> <a class="post-like">Like</a> <span class="dotpos">.</span> <abbr class="post-time" title="Wednesday, May 30, 2012 at 8:06pm">2 hours ago</abbr> </div>
                        </div>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                    <div class="comment-system">
                      <div class="comment-left"> <img src="inc/cmnt-img10.jpg" alt="comment-image" height="50" width="50"> </div>
                      <div class="comment-right"> <span class="profile-name">Alanna 'martin' Payne</span>
                        <div class="profile-content">
                          <div class="post-text">Thanks for the info, just started mine.</div>
                          <div> <a class="post-reply">Reply</a> <span class="dotpos">.</span> <span class="post-number">16</span> <a class="post-like">Like</a> <span class="dotpos">.</span> <abbr class="post-time" title="Wednesday, May 30, 2012 at 8:06pm">2 hours ago</abbr> </div>
                        </div>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                  </section>
                </div>
                <div class="sorterContainer dropdownMode" style="display: none;"><span class="dropdownButton">
                  <div class="dropDownContainer dropdownWidth" style="position: relative;">
                    <div class="moreButtonWrapper"> <span class="buttonTitle">Latest</span> <span class="dropdownPointerDown">▼</span> </div>
                    <div class="dropdown4001" style="display: none;">
                      <div class="dropdownContent">
                        <div class="dropdownIndent"></div>
                        <ul>
                          <li data-item="latest" class="select"><a>Latest</a></li>
                          <li data-item="top"><a>Top</a></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  </span> </div>
                <div class="pagerContainer" style="display: none;"><a class="secondaryButton toWidgetTop sm4IconToWidgetTops" style="display: none;"></a> <a class="secondaryButton pagerMore" style="display: none;">Show more</a></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      </b></div>
    <b>
    <nav class="wp-prev-next">
      <ul class="clearfix">
        <li class="show-more next-link"> </li>
      </ul>
    </nav>
    </b></div>
  <b> </b></div>
<div id="ddexitpopwrapper"><div class="veil"></div><div id="ddexitpop1" class="ddexitpop animated">
<a class="calltoaction cta-url-1" href="#" onclick="ddexitpop.hidepopup()"><img src="inc/pop1.jpg" class="img-fluid"></a>
</div></div>
<?php include("/home/forge/".$domain."/lpsource/footer.php"); ?>
</body></html>