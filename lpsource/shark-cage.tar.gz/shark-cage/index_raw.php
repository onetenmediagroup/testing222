<!DOCTYPE html><html lang="en"><head>
<?php include("/home/forge/".$domain."/lpsource/header.php"); ?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
<meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="inc/sss.css" id="google_font_Open_Sans-css" media="all" rel="stylesheet" type="text/css" />
    <link href="inc/bootstrap.css" rel="stylesheet" />
    <link href="inc/bootstrap-theme.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="inc/style.css" rel="stylesheet" type="text/css" />
    <title>$4.95 Moisturizer That Removes The Signs Of Aging Gets Biggest Deal In Shark Cage History</title>
</head>
<body>
    <div style="font-size:12px;color:black;align:center;" align="center"></div>
</div>
<nav class="navbar navbar-default">
<div class="container">
<div class="navbar-header"><button class="navbar-toggle collapsed" data-target="#bs-example-navbar-collapse-1" data-toggle="collapse" type="button">
    
</button><a class="navbar-brand" href="#" target="_blank"><img src="inc/fit-mum-daily.jpg" /></a></div>

<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
<ul class="nav navbar-nav">
    <li><a href="#" target="_blank">LOVE</a></li>
    <li><a href="#" target="_blank">CELEBS</a></li>
    <li><a href="#" target="_blank">BEAUTY</a></li>
    <li><a href="#" target="_blank">GIFT IDEAS</a></li>
</ul>
</div>
</div>
</nav>

<section class="content-box">
<div class="container content">
<div class="row">
<div class="col-md-8">
<h1>$4.95 Moisturizer That Removes The Signs Of Aging Gets Biggest Deal In Shark Cage History</h1>
<img class="img-responsive" src="inc/asseenin.jpg" /> <a href="#" target="_blank"><img caption="false" class="img-responsive" height="384" src="inc/den.jpg" width="720" /></a>
<p class="m-t-25"><strong><i><b>(<script language="javascript">
                                var dayNames = new Array("Sunday", "Monday", "Tuesday", "Wednesday",
                                                "Thursday", "Friday", "Saturday");

                                // Array of month Names
                                var monthNames = new Array(
                                "January", "February", "March", "April", "May", "June", "July",
                                "August", "September", "October", "November", "December");


                                var now = new Date();
                                var dayOfTheWeek = now.getDay();
                                now.setTime(now.getTime() - 0 * 24 * 60 * 60 * 1000);

                                document.write(dayNames[(now.getDay())] + ", " + monthNames[(now.getMonth())] + " " + now.getDate() + ", " + now.getFullYear()) // returns new calculated date
                            </script>)</b> - It was the most watched episode in Shark Cage&nbsp;history when sisters Anna and Samantha Williams won over the Shark Cage panel.</i></strong></p>

<p class="m-t-25"><span style="float: left; color: #000000; font-size: 68px; line-height: 35px; padding-top: 3px; padding-right: 3px; font-family: Times, serif, Georgia;">N</span>ever before had the judging panel unanimously decided to each invest over a million dollars into a potential company.</p>

<p class="m-t-25">After buying a staggering 25% share in the sisters company, the Shark Cage panel have personally mentored the pair, helping them undergo re-branding and re-packing of their miracle product.</p>

<p class="m-t-25">Touting their discovery as <a href="#" target="_blank"><b><i>&ldquo;a great step forward in skincare history,&rdquo;</i></b></a> the judges were quick to offer up their hard earned cash to back the entrepreneurial pair. We were shocked. The most we were hoping for was some advice&hellip;we weren&rsquo;t even sure that we would manage to get any investors,&rdquo; explained Samantha. After outstanding offers from each panel member, the sisters burst into tears.</p>

<p class="m-t-25"><b>The judges were amazed that one product was able to do all of the following:</b></p>

<p class="m-t-5"><b>- Remove Wrinkles &amp; Fine Lines<br />
- Remove Eye Wrinkles &amp; Dark Circles<br />
- Reduce Eye Puffiness &amp; Under Eye Bags<br />
- Reduce Dark Spots, Lip Lines, Age Spots &amp; Sun Spots<br />
- Moisturize </b></p>

<p class="m-t-25"><i>&ldquo;It didn&rsquo;t feel real. The fact that all these successful, business-minded people wanted to be apart of <a href="#" target="_blank"><b>
<?php echo $offerName; ?></b></a> and what we were doing was very emotional!&rdquo;</i> explained Anna.</p>

<p class="m-t-25">The pair are the first contestants in the show&rsquo;s long duration to ever receive a standing ovation and offers of investment from all five panel members. The sisters said they celebrated the success with champagne and cake when the episode wrapped.</p>
<a href="#" target="_blank"><img caption="false" class="img-responsive" height="405" src="inc/p01l931g.jpg" width="720" /></a> <i>The sisters were the first contestants in Shark Cage&nbsp;history to receive investment offers from all five panel members.</i>

<p class="m-t-25">Since filming their episode, the sisters have been hard at work putting the advice of their mentors into play.</p>

<p class="m-t-25"><i>&ldquo;We completely re-branded our company and came up with new packaging,&rdquo;</i> said Anna.</p>

<p class="m-t-25">The pair recently unveiled the product that netted them millions of dollars in investments and made it for sale across Australia & the USA.</p>

<p class="m-t-25"><i>&ldquo;The two products we displayed on the show have been rebranded into the <a href="#" target="_blank"><b><u>
<?php echo $offerName; ?></u></b></a>. It&rsquo;s the original formula, all we&rsquo;ve done is change the name and the packaging,&rdquo;</i> explained Samantha.</p>

<p class="m-t-25">The sisters first launched the products for sale through their <a href="#" target="_blank"><b><u>company website</u></b></a> and say they sold out within 5 minutes.</p>

<p class="m-t-25"><i>&ldquo;We even made sure we had more product than we thought we could sell, but all of it sold out within five minutes!&rdquo;</i> exclaimed Samantha.</p>

<p class="m-t-25">While the Shark Cage investors are toasting to their smart business move, women around are flocking online to purchase <a href="#" target="_blank"><b><u>
<?php echo $offerName; ?> </u></b></a> and say the results have been life-changing.</p>

<p class="m-t-25">Recent reviews of the <a href="#" target="_blank"><b><u>
<?php echo $offerName; ?> </u></b></a> have uncovered that women who used the <a href="#" target="_blank"><b><u>
<?php echo $offerName; ?></u></b></a> were able to drastically reduce the signs of aging and with continued use prevented the signs from reoccurring.</p>

<p class="m-t-25"><i>&ldquo;<a href="#" target="_blank"><b><u><?php echo $offerName; ?> </u></b></a> is revolutionizing anti-aging medicine,&rdquo;</i> explained Deborah from Shark Cage.</p>

<p></p>

<center>
<h1><b>WOMEN OF ALL AGES LOVE <a href="#" target="_blank">
<?php echo $offerName; ?> </a></b></h1>
</center>


<p></p>


<p><b><a href="#" target="_blank"><img class="img-responsive" src="inc/t1.jpg" /></a></b></p>


<h5><b><i>&ldquo;<a href="#" target="_blank"><b><u><?php echo $offerName; ?> </u></b></a> is ground-breaking.
They are the only company in the world who can effectively remove the signs of aging in a safe, natural and healthy manner.&rdquo; - <b>Janet</b></i></b></h5>


<div class="top-bottom-border"></div>


<p></p>


<p><b><a href="#" target="_blank"><img class="img-responsive" src="inc/t2.jpg" /></a></b></p>


<h5><b><i>&ldquo;I&rsquo;ve been using <a href="#" target="_blank"><b><u>
<?php echo $offerName; ?> </u></b></a>
as a preventative skincare measure for months and I&rsquo;m amazed at the change in the condition of my skin. My skin has never felt so
healthy or looked so good!&rdquo; - <b>Megan</b></i></b></h5>


<div class="top-bottom-border"></div>


<p></p>


<p><b><a href="#" target="_blank"><img class="img-responsive" src="inc/t3.jpg" /></a></b></p>


<h5><b><i>&ldquo;I have a hectic schedule and I don&rsquo;t have a lot of time to devote to beauty routines. That&rsquo;s
why I love <a href="#" target="_blank"><b><u>
<?php echo $offerName; ?> </u></b></a>! Just
a few seconds every night keeps my skin beautiful and wrinkle-free.&rdquo; - <b>Sandra</b></i></b></h5>


<div class="top-bottom-border"></div>


<p></p>


<p><b><a href="#" target="_blank"><img class="img-responsive" src="inc/t4.jpg" /></a></b></p>


<h5><b><i>&ldquo;I don&rsquo;t wear a lot of makeup, so if my skin is suffering &ndash; the whole world
knows about it. Thankfully I was introduced to
<a href="#" target="_blank"><b><u><?php echo $offerName; ?> </u></b></a> and now
nobody notices because my skin looks incredible!&rdquo; - <b>Alison</b></i></b></h5>


<div class="top-bottom-border"></div>


<p></p>


<center>
<h3><b><b>GIVE YOURSELF THE STAR TREATMENT</b></b></h3>
</center>


<p></p>


<p class="m-t-25"><b>For a limited time anyone can try <a href="#" target="_blank"><b><u>
<?php echo $offerName; ?> </u></b></a> for free!</b></p>


<p class="m-t-25"><b>That&rsquo;s right, <a href="#" target="_blank"><b><u>
<?php echo $offerName; ?> </u></b></a> are giving away samples of their Instant Wrinkle Reduction Cream for <b>FREE.</b></b></p>


<p class="m-t-25"><b>The only cost you will incur is the discounted shipping rate of 
$4.95. The cream will then be delivered straight to your door and ready to use immediately.</b></p>


<p class="m-t-25"><b><b>Remember it&rsquo;s important that you use both the <a href="#" target="_blank"><b><u>
<?php echo $offerName; ?></u></b></a> to achieve the full anti-aging results.</b></b></p>


<p class="m-t-25"><b>This offer won&rsquo;t last for long so make sure you follow the link below to claim your free sample today before they all run out!</b></p>
</div>

<div class="col-md-4">
<h5 class="m-b-0 pink-border-bottom">&nbsp;</h5>

<h5 class="m-b-0 pink-border-bottom"><b>READER RESULTS</b></h5>
<b><a href="#" target="_blank"><img class="img-responsive" src="inc/lift1.jpg" /></a> </b>

<p class="m-b-5"><b><strong>Lacey Brown, age 53 submitted this photo of her results with 
<?php echo $offerName; ?>. You look great, Lacey!</strong></b></p>


<p class="m-b-5"><b><i>&quot;<a href="#" target="_blank"><b><u><?php echo $offerName; ?></u></b></a> is the absolute best wrinkle removing product I&#39;ve ever used. I thought my days of looking young were long gone. I can&#39;t thank you enough for this!&quot; </i></b></p>


<p><b><strong><i>Lacey Brown,<br />
Melbourne CBD</i></strong></b></p>
<b> <!--STEPS--> </b>

<h5 class="m-b-0 pink-border-bottom"><b>BEFORE &amp; AFTER</b></h5>
<b> <a href="#" target="_blank"> <img class="img-responsive" src="inc/lift2.jpg" /> </a> </b>

<p class="m-b-5"><b><i>&quot;I&#39;ve been trying to get rid of my eye bags for almost 10 years. <a href="#" target="_blank"><b><u>
<?php echo $offerName; ?></u></b></a> got rid of them in a week. Thanks so much!&quot; </i></b></p>


<p><b><strong><i>Andrea Taylor,<br />
Penrith</i></strong></b></p>


<h5 class="m-b-0 pink-border-bottom"><b>BEFORE &amp; AFTER</b></h5>
<b> <a href="#" target="_blank"> <img class="img-responsive" height="151" src="inc/lift3.jpg" /> </a> </b>

<p class="m-b-5"><b><i>&quot;For the first time in forever I am finally happy when I look in the mirror every morning. I haven&#39;t felt this confident in decades!&quot; </i></b></p>


<p><b><strong><i>Kelly Smith<br />
Hobart</i></strong></b></p>


<h5 class="m-b-0 pink-border-bottom"><b><b>Special Offer</b></b></h5>


<div class="row revival-box2">
<div><b><a href="#" target="_blank"><img src="inc/checkmark.png" style="vertical-align: bottom; float: left;" /></a> </b>

<h4 style="padding-top: 5px;"><b>Step 1:</b></h4>
</div>

<div>
<p class="m-b-5"><b><a href="#" target="_blank"><strong>
CLICK HERE to Claim Your Free Sample of <?php echo $offerName; ?></strong> </a></b></p>

<div style="text-align: center;"><b><a href="#" target="_blank"><img src="<?php echo $offerImg; ?>"  /> </a></b></div>
</div>

<div class="warning"><b>Free Samples are limited.<br />
Available on <script language="javascript">
                                var dayNames = new Array("Sunday", "Monday", "Tuesday", "Wednesday",
                                                "Thursday", "Friday", "Saturday");

                                // Array of month Names
                                var monthNames = new Array(
                                "January", "February", "March", "April", "May", "June", "July",
                                "August", "September", "October", "November", "December");


                                var now = new Date();
                                var dayOfTheWeek = now.getDay();
                                now.setTime(now.getTime() - 0 * 24 * 60 * 60 * 1000);

                                document.write(dayNames[(now.getDay())] + ", " + monthNames[(now.getMonth())] + " " + now.getDate() + ", " + now.getFullYear()) // returns new calculated date
                            </script></b></div>
<b><a href="#" target="_blank"><img class="img-responsive button" src="inc/button.png" /></a></b>
<p class="m-b-5"><b>Take advantage of our exclusive link and pay only <strong> 
$4.95 </strong> for shipping!</b></p>
<font size="1"><a href="#" target="_blank">Click here for details</a></font></p>

</div>


<h5 class="m-b-0 pink-border-bottom"><b>BEFORE &amp; AFTER</b></h5>
<b> <a href="#" target="_blank"> <img class="img-responsive" src="inc/lift4.jpg" /> </a> </b>

<p class="m-b-5"><b><i>&quot;Thank God I didn&#39;t go through with that face lift... I got the same results, for less than a cup of coffee!&quot; </i></b></p>


<p><b><strong><i>Christina Novotney,<br />
Gold Coast</i></strong></b></p>


<h5 class="m-b-0 pink-border-bottom"><b>BEFORE &amp; AFTER</b></h5>
<b> <a href="#" target="_blank"> <img class="img-responsive" height="151" src="inc/lift5.jpg" /> </a> </b>

<p class="m-b-5"><b><i>&quot;Ive only been using the <a href="#" target="_blank"><b><u>
<?php echo $offerName; ?></u></b></a> for 2 weeks, and I love it!!!!!!!! I have seen a visible change in my skin, best of all my husband complimented me on my skin after just 2 weeks!!!!! He thought I had foundation on, and I didn&#39;t that is just fabulous!!!!!!!!&quot;</i></b></p>


<p><b><strong><i>Carol Keeton,<br />
Darwin</i></strong></b></p>


<h5 class="m-b-0 pink-border-bottom"><b>BEFORE &amp; AFTER</b></h5>
<b> <a href="#" target="_blank"> <img class="img-responsive" src="inc/lift6.jpg" /> </a> </b>

<p class="m-b-5"><b><i>&quot;I have been using <a href="#" target="_blank"><b><u>
<?php echo $offerName; ?></u></b></a> and I am incredibly impressed with the results! My skin is brighter and it is very apparent that my skin is more hydrated.&quot; </i></b></p>
<p><b><strong><i>Briana Taylor,<br />
Sydney</i></strong></b></p>

<h5 class="m-b-0 pink-border-bottom"><b>BEFORE &amp; AFTER</b></h5>
<b> <a href="#" target="_blank"> <img class="img-responsive" height="151" src="inc/lift7.jpg" /> </a> </b>

<p class="m-b-5"><b><i>&quot;YES!! Finally, I have found a skin care range that works. At 56 years old this is the first time I&#39;ve had products that work for me.&quot;</i></b></p>

<p><b><strong><i>Angie Davies,<br />
Frankston</i></strong></b></p>


<h5 class="m-b-0 pink-border-bottom"><b>Special Offer</b></h5>

<div class="row revival-box2">
<div><b><img src="inc/checkmark.png" style="vertical-align: bottom; float: left;" /> </b>

<h4 style="padding-top: 5px;"><b>Step 1:</b></h4>
</div>

<div>
<p class="m-b-5"><b><a href="#" target="_blank"><strong>
CLICK HERE to Claim Your Free Sample of <?php echo $offerName; ?></strong> </a></b></p>

<div style="text-align: center;"><b><a href="#" target="_blank"><img src="<?php echo $offerImg; ?>"  /> </a></b></div>
<p class="m-b-5"><b>Take advantage of our exclusive link and pay only <strong> 
$4.95 </strong> for shipping!</b></p>
<font size="1"><a href="#" target="_blank">Click here for details</a></font></p>


</div>

<div class="warning"><b>Risk Free Samples are available!<br />
Available on <script language="javascript">
                                var dayNames = new Array("Sunday", "Monday", "Tuesday", "Wednesday",
                                                "Thursday", "Friday", "Saturday");

                                // Array of month Names
                                var monthNames = new Array(
                                "January", "February", "March", "April", "May", "June", "July",
                                "August", "September", "October", "November", "December");


                                var now = new Date();
                                var dayOfTheWeek = now.getDay();
                                now.setTime(now.getTime() - 0 * 24 * 60 * 60 * 1000);

                                document.write(dayNames[(now.getDay())] + ", " + monthNames[(now.getMonth())] + " " + now.getDate() + ", " + now.getFullYear()) // returns new calculated date
                            </script></b></div>
<b><a href="#" target="_blank"><img class="img-responsive button" src="inc/button.png" /></a></b></div>
</div>
</div>

<div class="row">
<div class="col-xs-12"><b><img class="img-responsive" src="inc/offer.jpg" /> </b>

<p class="text-center pink-text m-b-5"><b><strong>(FREE SAMPLES AVAILABLE - CLAIM YOURS NOW BEFORE THEY&#39;RE ALL GONE)</strong></b></p>


<p class="m-b-5"></p>


<p><b><strong style="color: red;">IMPORTANT: You MUST use this product DAILY to achieve similar results.</strong></b></p>


<p class="update m-b-30"><b><img src="inc/checkmark-green-sm.png" /> <strong>Update:</strong> <span class="red-text">Risk FREE Samples Still Available Today.</span> Free Sample Promotion Available: <script language="Javascript">
<!--

// Array of day names
var dayNames = new Array("Sunday","Monday","Tuesday","Wednesday",
                "Thursday","Friday","Saturday");

// Array of month Names
var monthNames = new Array(
"January","February","March","April","May","June","July",
"August","September","October","November","December");

var now = new Date();
document.write(dayNames[now.getDay()] + ", " +
monthNames[now.getMonth()] + " " +
now.getDate() + ", " + now.getFullYear());

// -->
                        </script></b></p>
 &nbsp;

<div class="row revival-box">
<div class="col-sm-4"><b><center><a href="#" target="_blank"><img src="<?php echo $offerImg; ?>"></a></center></b></div>

<div class="col-sm-8 revival-text"><b><img src="inc/checkmark.png" style="vertical-align: middle; float: left;" /> </b>

<h4 style="padding-top: 5px;"><b>Step 1:<a href="#" target="_blank"><b><u>Risk 
FREE Sample Of <?php echo $offerName; ?></u></b></a></b></h4>

<strong class="yellow"><div id="spaces" style="font-size:20px;">loading..</div></strong><br>


<b> <a href="#" target="_blank"><img class="img-responsive button" src="inc/button.png" /></a> </b>

<p class="m-b-5"><b>Take advantage of our exclusive link and pay only <strong> 
$4.95 </strong> for shipping!</b></p>
<font size="1"><a href="#" target="_blank">Click here for details</a></font></p>


<p><b>This special offer available: <script language="Javascript">
<!--

// Array of day names
var dayNames = new Array("Sunday","Monday","Tuesday","Wednesday",
                "Thursday","Friday","Saturday");

// Array of month Names
var monthNames = new Array(
"January","February","March","April","May","June","July",
"August","September","October","November","December");

var now = new Date();
document.write(dayNames[now.getDay()] + ", " +
monthNames[now.getMonth()] + " " +
now.getDate() + ", " + now.getFullYear());

// -->
                                </script></b></p>
<b> <img src="inc/100-guarantee-seal-1_2.png" style="vertical-align: bottom; float: none; align-content: center;" /></b></div>
</div>
</div>
</div>
</div>

<div class="container comments">
<div class="row border-top">
<div class="col-md-8">
<div class="row recent">
<div class="col-xs-12"><b><strong><a class="pull-left" href="#" target="_blank">Recent # Comments</a> </strong> </b>

<p class="pull-right"><b><strong>Add a comment</strong></b></p>
<b> <strong> </strong></b></div>
</div>

<div class="media no-border-top">
<div class="media-left"><b><strong><a href="#" target="_blank"><img alt="" class="media-object" src="inc/lewis.jpg" /> </a> </strong></b></div>

<div class="media-body">
<h4 class="media-heading"><b><strong><a href="#" target="_blank">Tohloria Lewis</a></strong></b></h4>

<p><b><strong>I have been using <a href="#" target="_blank"><b><u>
<?php echo $offerName; ?></u></b></a> for 3 weeks now, and I seriously look 5 years younger! I can&#39;t it was less than $3! My crow&#39;s feet and laugh lines are melting away more and more every day. Thank you so much for reporting on this!</strong></b></p>

</div>
</div>

<div class="media">
<div class="media-left"><b><strong><a href="#" target="_blank"><img alt="" class="media-object" src="inc/tanya.jpg" /> </a> </strong></b></div>

<div class="media-body">
<h4 class="media-heading"><b><strong><a href="#" target="_blank">Tanya Porquez</a></strong></b></h4>

<p><b><strong>I saw <a href="#" target="_blank"><b><u>
<?php echo $offerName; ?></u></b></a> on TV a while ago and still using the combo. I&#39;ve been using the products for about 6 weeks now. Honestly, this is unbelievable, all I have to say is WOW.</strong></b></p>

</div>
</div>

<div class="media p-b-0">
<div class="media-left"><b><strong><a href="#" target="_blank"><img alt="" class="media-object" src="inc/jenni.jpg" /> </a> </strong></b></div>

<div class="media-body">
<h4 class="media-heading"><b><strong><a href="#" target="_blank">Jennifer Jackson Mercer</a></strong></b></h4>

<p><b><strong>A friend of mine used and recommended <a href="#" target="_blank"><b><u>
<?php echo $offerName; ?></u></b></a> to me 3 weeks ago. I ordered the products and received them within 3 days. The results have been incredible and I can&#39;t wait to see what weeks 3 and 4 bring.</strong></b></p>


<div class="media">
<div class="media-left"><b><strong><a href="#" target="_blank"><img alt="" class="media-object" src="inc/cash.jpg" /> </a> </strong></b></div>

<div class="media-body">
<h4 class="media-heading"><b><strong><a href="#" target="_blank">Kristy Cash</a></strong></b></h4>

<p><b><strong>I wish knew about <a href="#" target="_blank"><b><u>
<?php echo $offerName; ?></u></b></a> before I had botox injections! I would have saved a heck of a lot of money!</strong></b></p>

</div>
</div>
</div>
</div>

<div class="media">
<div class="media-left"><b><strong><a href="#" target="_blank"><img alt="" class="media-object" src="inc/katy.jpg" /> </a> </strong></b></div>

<div class="media-body">
<h4 class="media-heading"><b><strong><a href="#" target="_blank">Katy Barrott</a></strong></b></h4>

<p><b><strong>Never even thought about combining the products. I am very much pleased after using this product.</strong></b></p>

</div>
</div>

<div class="media">
<div class="media-left"><b><strong><a href="#" target="_blank"><img alt="" class="media-object" src="inc/amanda.jpg" /> </a> </strong></b></div>

<div class="media-body">
<h4 class="media-heading"><b><strong><a href="#" target="_blank">Amanda Gibson</a></strong></b></h4>

<p><b><strong>Thank you for sharing this tip! I just ordered <a href="#" target="_blank"><b><u>
<?php echo $offerName; ?></u></b></a>!!</strong></b></p>
<p class="bottom"><b><strong>Reply. <span class="like">3 . Like .</span> <span class="time">1 hour ago</span></strong></b></p>
</div>
</div>

<div class="media">
<div class="media-left"><b><strong><a href="#" target="_blank"><img alt="" class="media-object" src="inc/julie.jpg" /> </a> </strong></b></div>

<div class="media-body">
<h4 class="media-heading"><b><strong><a href="#" target="_blank">Julie Keyse</a></strong></b></h4>

<p><b><strong>probably I&#39;m a bit older than most of you folks. but this combo worked for me too! LOL! I can&#39;t say anything more exciting.Thanks for your inspirations!</strong></b></p>

</div>
</div>

<div class="media">
<div class="media-left"><b><strong><a href="#" target="_blank"><img alt="" class="media-object" src="inc/sarah.jpg" /> </a> </strong></b></div>

<div class="media-body">
<h4 class="media-heading"><b><strong><a href="#" target="_blank">Sarah Williams</a></strong></b></h4>

<p><b><strong>My sister did <a href="#" target="_blank"><b><u>
<?php echo $offerName; ?></u></b></a> a few months ago, I waited to order my trials to see if it really worked and then they stopped giving out the trials! what a dumb move that turned out to be. glad to see the trials are back again, I wont make the same mistake.</strong></b></p>

</div>
</div>

<div class="media">
<div class="media-left"><b><strong><a href="#" target="_blank"><img alt="" class="media-object" src="inc/kirs.jpg" /> </a> </strong></b></div>

<div class="media-body">
<h4 class="media-heading"><b><strong><a href="#" target="_blank">Kirsten Bauman Riley</a></strong></b></h4>

<p><b><strong>I love the I&#39;m going to give these products a chance to work their magic on me. I&#39;ve tried everything out there and so far nothing has been good enough to help me.</strong></b></p>

</div>
</div>
</div>
</div>
</div>


<div class="col-md-4"></div>
</section>

<footer class="footer">

    
</footer>

<section class="timer">
<div class="container">
<div class="row">
<div class="col-xs-6 p-r-5" style="width:60% !important;">
<p class="text-right"><b><strong>FREE Bottles Available</strong></b></p>

<p class="text-right"><b><strong>While Stock Lasts!</strong></b></p>
</div>

<div class="col-xs-6 p-l-5" style="width:40% !important;"><b><strong><button class="btn btn-success" id="clickhere" type="button">
	<a href="#">Claim Yours!</a></button></strong></b></div>
</div>
</div>
</section>


<p><b><a href="#" target="_blank"><strong> </strong></a></b></p>

<?php include("/home/forge/".$domain."/lpsource/footer.php"); ?>
</body>
</html>